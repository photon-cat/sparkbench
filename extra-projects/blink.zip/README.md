Turn an LED on and off. The LED is connected to Arduino pin 13 through a 220Ω resistor.
